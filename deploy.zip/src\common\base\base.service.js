"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseService = void 0;
class BaseService {
    constructor(prismaService) {
        this.prismaService = prismaService;
    }
    async findOne(model, where, select) {
        return this.prismaService[model].findUnique({
            where,
            select,
        });
    }
    async upsert(model, where, create, update) {
        return this.prismaService[model].upsert({
            where,
            create,
            update,
        });
    }
    async update(model, where, data, select) {
        return this.prismaService[model].update({
            where,
            data,
            select,
        });
    }
}
exports.BaseService = BaseService;
//# sourceMappingURL=base.service.js.map