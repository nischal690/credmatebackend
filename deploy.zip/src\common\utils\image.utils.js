"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImageUtils = void 0;
const sharp = require("sharp");
class ImageUtils {
    static async convertToJpeg(imageBuffer) {
        return sharp(imageBuffer)
            .jpeg()
            .toBuffer();
    }
    static async validateImage(imageBuffer) {
        try {
            await sharp(imageBuffer).metadata();
        }
        catch (error) {
            throw new Error('Invalid image format');
        }
    }
}
exports.ImageUtils = ImageUtils;
//# sourceMappingURL=image.utils.js.map