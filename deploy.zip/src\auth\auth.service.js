"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AuthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = exports.TokenValidationError = void 0;
const common_1 = require("@nestjs/common");
const firebase_service_1 = require("./firebase.service");
const jwt = require("jsonwebtoken");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
const prisma_service_1 = require("../../database/prisma/prisma.service");
class TokenValidationError extends Error {
    constructor(code, message, details) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = 'TokenValidationError';
    }
}
exports.TokenValidationError = TokenValidationError;
let AuthService = AuthService_1 = class AuthService {
    constructor(firebaseService, configService, prismaService) {
        this.firebaseService = firebaseService;
        this.configService = configService;
        this.prismaService = prismaService;
        this.logger = new common_1.Logger(AuthService_1.name);
        this.jwtSecret = this.getRequiredConfig('JWT_SECRET');
        this.jwtExpiresIn = this.configService.get('JWT_ACCESS_TOKEN_EXPIRES_IN') || '30m';
        this.refreshTokenSecret = this.getRequiredConfig('JWT_REFRESH_SECRET');
        this.refreshTokenExpiresIn = this.configService.get('JWT_REFRESH_TOKEN_EXPIRES_IN') || '7d';
    }
    getRequiredConfig(key) {
        const value = this.configService.get(key);
        if (!value) {
            throw new Error(`Required configuration ${key} is missing`);
        }
        return value;
    }
    generateUniqueId(phoneNumber) {
        const cleanPhone = phoneNumber.replace(/\D/g, '');
        const hash = (0, crypto_1.createHash)('sha256')
            .update(cleanPhone)
            .digest('hex')
            .substring(0, 16);
        return `u${cleanPhone.slice(-4)}${hash}`;
    }
    generateTokens(payload) {
        const accessToken = jwt.sign(payload, this.jwtSecret, {
            expiresIn: this.jwtExpiresIn,
            algorithm: 'HS256',
            audience: this.configService.get('JWT_AUDIENCE') || undefined,
            issuer: this.configService.get('JWT_ISSUER') || undefined,
        });
        const refreshToken = jwt.sign(payload, this.refreshTokenSecret, {
            expiresIn: this.refreshTokenExpiresIn,
            algorithm: 'HS256',
        });
        const accessTokenExpiresIn = this.parseTimeToSeconds(this.jwtExpiresIn);
        const refreshTokenExpiresIn = this.parseTimeToSeconds(this.refreshTokenExpiresIn);
        return {
            accessToken,
            refreshToken,
            accessTokenExpiresIn,
            refreshTokenExpiresIn,
        };
    }
    parseTimeToSeconds(time) {
        const unit = time.slice(-1);
        const value = parseInt(time.slice(0, -1));
        switch (unit) {
            case 's': return value;
            case 'm': return value * 60;
            case 'h': return value * 60 * 60;
            case 'd': return value * 24 * 60 * 60;
            default: return 30 * 60;
        }
    }
    async validateFirebaseToken(idToken) {
        try {
            this.logger.debug('Validating Firebase token...');
            const decodedToken = (await this.firebaseService.verifyIdToken(idToken));
            if (!decodedToken.uid) {
                throw new TokenValidationError('INVALID_TOKEN_PAYLOAD', 'Firebase token missing required uid field');
            }
            if (!decodedToken.phone_number) {
                throw new TokenValidationError('INVALID_TOKEN_PAYLOAD', 'Firebase token missing required phone number');
            }
            const uniqueId = this.generateUniqueId(decodedToken.phone_number);
            await this.prismaService.user.upsert({
                where: { phoneNumber: decodedToken.phone_number },
                update: {
                    uniqueId: uniqueId,
                    email: decodedToken.email,
                    name: decodedToken.name,
                },
                create: {
                    phoneNumber: decodedToken.phone_number,
                    uniqueId: uniqueId,
                    email: decodedToken.email,
                    name: decodedToken.name,
                },
            });
            const jwtPayload = {
                uid: decodedToken.uid,
                phoneNumber: decodedToken.phone_number,
                uniqueId: uniqueId,
                email: decodedToken.email,
                name: decodedToken.name,
            };
            return this.generateTokens(jwtPayload);
        }
        catch (error) {
            this.logger.error('Token validation failed', {
                error: error.message,
                code: error.code,
                timestamp: new Date().toISOString(),
            });
            if (error instanceof TokenValidationError) {
                throw error;
            }
            if (error.code === 'auth/id-token-expired') {
                throw new TokenValidationError('TOKEN_EXPIRED', 'Firebase token has expired');
            }
            if (error.code === 'auth/id-token-revoked') {
                throw new TokenValidationError('TOKEN_REVOKED', 'Firebase token has been revoked');
            }
            throw new TokenValidationError('VALIDATION_ERROR', 'Failed to validate Firebase token', error);
        }
    }
    async refreshAccessToken(refreshToken) {
        try {
            const decoded = jwt.verify(refreshToken, this.refreshTokenSecret, {
                algorithms: ['HS256'],
            });
            return this.generateTokens(decoded);
        }
        catch (error) {
            if (error instanceof jwt.TokenExpiredError) {
                throw new TokenValidationError('REFRESH_TOKEN_EXPIRED', 'Refresh token has expired');
            }
            throw new TokenValidationError('INVALID_REFRESH_TOKEN', 'Invalid refresh token');
        }
    }
    async verifyCustomToken(token) {
        try {
            const decoded = jwt.verify(token, this.jwtSecret, {
                algorithms: ['HS256'],
                audience: this.configService.get('JWT_AUDIENCE') || undefined,
                issuer: this.configService.get('JWT_ISSUER') || undefined,
            });
            if (!decoded.uniqueId) {
                throw new TokenValidationError('INVALID_TOKEN_PAYLOAD', 'Token missing required uniqueId field');
            }
            return decoded;
        }
        catch (error) {
            if (error instanceof TokenValidationError) {
                throw error;
            }
            if (error instanceof jwt.TokenExpiredError) {
                throw new TokenValidationError('TOKEN_EXPIRED', 'JWT token has expired');
            }
            throw new TokenValidationError('VALIDATION_ERROR', 'Failed to validate JWT token');
        }
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = AuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [firebase_service_1.FirebaseService,
        config_1.ConfigService,
        prisma_service_1.PrismaService])
], AuthService);
//# sourceMappingURL=auth.service.js.map