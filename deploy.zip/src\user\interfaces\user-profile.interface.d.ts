export interface UserProfileResponse {
    name: string;
    date_of_birth?: Date;
    businessType?: string;
}
