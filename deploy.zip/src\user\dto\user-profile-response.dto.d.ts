export declare class UserProfileResponseDto {
    name: string;
    date_of_birth?: Date;
    businessType?: string;
}
