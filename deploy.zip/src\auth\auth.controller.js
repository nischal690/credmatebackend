"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuthController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = exports.RefreshTokenDto = exports.GenerateTokenDto = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("./auth.service");
const class_validator_1 = require("class-validator");
const firebase_auth_error_1 = require("./errors/firebase-auth.error");
const swagger_1 = require("@nestjs/swagger");
class GenerateTokenDto {
}
exports.GenerateTokenDto = GenerateTokenDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], GenerateTokenDto.prototype, "idToken", void 0);
class RefreshTokenDto {
}
exports.RefreshTokenDto = RefreshTokenDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], RefreshTokenDto.prototype, "refreshToken", void 0);
let AuthController = AuthController_1 = class AuthController {
    constructor(authService) {
        this.authService = authService;
        this.logger = new common_1.Logger(AuthController_1.name);
    }
    async generateToken(body) {
        this.logger.log('Attempting to generate tokens for request');
        try {
            const tokens = await this.authService.validateFirebaseToken(body.idToken);
            this.logger.log('Tokens generated successfully');
            return {
                success: true,
                ...tokens,
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            this.logger.error('Token generation failed', {
                errorName: error.name,
                errorMessage: error.message,
                errorCode: error.code,
                timestamp: new Date().toISOString(),
            });
            const errorResponse = {
                success: false,
                message: error.message,
                code: error.code,
                timestamp: new Date().toISOString(),
            };
            if (error.name === 'TokenValidationError') {
                if (error.code === 'TOKEN_EXPIRED') {
                    throw new common_1.BadRequestException({
                        ...errorResponse,
                        message: 'Your Firebase ID token has expired. Please log in again to continue.',
                        details: 'Firebase ID token has expired. Please obtain a new token by re-authenticating.',
                    });
                }
            }
            if (error instanceof firebase_auth_error_1.FirebaseAuthError || error.name === 'FirebaseAuthError') {
                switch (error.code) {
                    case 'auth/id-token-expired':
                        throw new common_1.BadRequestException({
                            ...errorResponse,
                            message: 'Your Firebase ID token has expired. Please log in again to continue.',
                            details: 'Firebase ID token has expired. Please obtain a new token by re-authenticating.',
                        });
                    case 'auth/invalid-id-token':
                        throw new common_1.BadRequestException({
                            ...errorResponse,
                            message: 'Invalid authentication token. Please try logging in again.',
                        });
                    case 'auth/user-disabled':
                        throw new common_1.BadRequestException({
                            ...errorResponse,
                            message: 'Your account has been disabled. Please contact support.',
                            status: common_1.HttpStatus.FORBIDDEN,
                        });
                    case 'auth/user-not-found':
                        throw new common_1.BadRequestException({
                            ...errorResponse,
                            message: 'User account not found. Please register first.',
                            status: common_1.HttpStatus.NOT_FOUND,
                        });
                    default:
                        throw new common_1.BadRequestException({
                            ...errorResponse,
                            message: 'Authentication failed. Please try logging in again.',
                        });
                }
            }
            throw new common_1.InternalServerErrorException({
                success: false,
                message: 'An unexpected error occurred during authentication. Please try again.',
                code: error.code || 'INTERNAL_ERROR',
                timestamp: new Date().toISOString(),
            });
        }
    }
    async refreshToken(body) {
        try {
            const tokens = await this.authService.refreshAccessToken(body.refreshToken);
            return {
                success: true,
                ...tokens,
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            throw new common_1.BadRequestException({
                success: false,
                message: error.message,
                timestamp: new Date().toISOString(),
            });
        }
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Post)('token'),
    (0, swagger_1.ApiOperation)({ summary: 'Generate access and refresh tokens from Firebase ID token' }),
    (0, swagger_1.ApiBody)({ type: GenerateTokenDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Tokens generated successfully',
        schema: {
            type: 'object',
            properties: {
                success: { type: 'boolean' },
                accessToken: { type: 'string' },
                refreshToken: { type: 'string' },
                accessTokenExpiresIn: { type: 'number', description: 'Access token expiration time in seconds' },
                refreshTokenExpiresIn: { type: 'number', description: 'Refresh token expiration time in seconds' },
                timestamp: { type: 'string' },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({
        status: 401,
        description: 'Token validation failed',
        schema: {
            type: 'object',
            properties: {
                success: { type: 'boolean' },
                message: { type: 'string' },
                code: { type: 'string' },
                timestamp: { type: 'string' },
            },
        },
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [GenerateTokenDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "generateToken", null);
__decorate([
    (0, common_1.Post)('refresh'),
    (0, swagger_1.ApiOperation)({ summary: 'Generate new access token using refresh token' }),
    (0, swagger_1.ApiBody)({ type: RefreshTokenDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'New access token generated successfully',
        schema: {
            type: 'object',
            properties: {
                success: { type: 'boolean' },
                accessToken: { type: 'string' },
                refreshToken: { type: 'string' },
                expiresIn: { type: 'number' },
                timestamp: { type: 'string' },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid refresh token',
        schema: {
            type: 'object',
            properties: {
                success: { type: 'boolean' },
                message: { type: 'string' },
                timestamp: { type: 'string' },
            },
        },
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [RefreshTokenDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "refreshToken", null);
exports.AuthController = AuthController = AuthController_1 = __decorate([
    (0, swagger_1.ApiTags)('auth'),
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map