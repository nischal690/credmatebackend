export declare function generateTestToken(jwtSecret?: string): string;
