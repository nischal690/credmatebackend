"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidationUtils = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
class ValidationUtils {
    static async validateDTO(dto) {
        const errors = await (0, class_validator_1.validate)(dto);
        if (errors.length > 0) {
            const validationErrors = errors.map((error) => ({
                property: error.property,
                constraints: error.constraints,
            }));
            throw new common_1.BadRequestException({
                message: 'Validation failed',
                errors: validationErrors,
            });
        }
    }
    static validateRequiredFields(obj, requiredFields) {
        for (const field of requiredFields) {
            if (obj[field] === undefined || obj[field] === null) {
                throw new common_1.BadRequestException(`${field} is required`);
            }
        }
    }
}
exports.ValidationUtils = ValidationUtils;
//# sourceMappingURL=validation.utils.js.map