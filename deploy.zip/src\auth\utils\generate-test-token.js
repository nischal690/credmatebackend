"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateTestToken = generateTestToken;
const jwt = require("jsonwebtoken");
function generateTestToken(jwtSecret = 'your-test-secret-key') {
    const dummyPayload = {
        uid: 'test-user-123',
        email: 'test@example.com',
        phoneNumber: '+1234567890',
        emailVerified: true,
        name: 'Test User',
        picture: 'https://example.com/test-user.jpg'
    };
    const token = jwt.sign(dummyPayload, jwtSecret, {
        expiresIn: '1d',
        algorithm: 'HS256',
        audience: process.env.JWT_AUDIENCE || 'test-audience',
        issuer: process.env.JWT_ISSUER || 'test-issuer',
        notBefore: 0
    });
    return token;
}
if (require.main === module) {
    const token = generateTestToken();
    console.log('Test JWT Token:');
    console.log(token);
    const decoded = jwt.decode(token);
    console.log('\nDecoded Token:');
    console.log(JSON.stringify(decoded, null, 2));
    console.log('\nTo use this token in your API requests:');
    console.log('Authorization: Bearer ' + token);
}
//# sourceMappingURL=generate-test-token.js.map