"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = exports.UpdateUserProfileDto = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../database/prisma/prisma.service");
const firebase_service_1 = require("../auth/firebase.service");
const auth_service_1 = require("../auth/auth.service");
const base_service_1 = require("../common/base/base.service");
const validation_utils_1 = require("../common/utils/validation.utils");
const class_validator_1 = require("class-validator");
class UpdateUserProfileDto {
}
exports.UpdateUserProfileDto = UpdateUserProfileDto;
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateUserProfileDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], UpdateUserProfileDto.prototype, "date_of_birth", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateUserProfileDto.prototype, "businessType", void 0);
let UserService = class UserService extends base_service_1.BaseService {
    constructor(prismaService, firebaseService, authService) {
        super(prismaService);
        this.prismaService = prismaService;
        this.firebaseService = firebaseService;
        this.authService = authService;
    }
    async getUserProfile(token) {
        const decodedToken = await this.authService.verifyCustomToken(token);
        validation_utils_1.ValidationUtils.validateRequiredFields(decodedToken, ['uniqueId']);
        const user = await this.findOne('user', { uniqueId: decodedToken.uniqueId }, {
            name: true,
            date_of_birth: true,
            businessType: true,
        });
        if (!user) {
            throw new common_1.UnauthorizedException('User not found');
        }
        return user;
    }
    async updateUserProfile(decodedToken, userData) {
        validation_utils_1.ValidationUtils.validateRequiredFields(decodedToken, ['uniqueId']);
        await validation_utils_1.ValidationUtils.validateDTO(userData);
        const updateData = this.filterUpdateData(userData);
        return this.update('user', { uniqueId: decodedToken.uniqueId }, updateData, {
            name: true,
            date_of_birth: true,
            businessType: true,
        });
    }
    filterUpdateData(userData) {
        const updateData = {};
        if (userData.name !== undefined)
            updateData.name = userData.name;
        if (userData.date_of_birth !== undefined)
            updateData.date_of_birth = new Date(userData.date_of_birth);
        if (userData.businessType !== undefined)
            updateData.businessType = userData.businessType;
        return updateData;
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        firebase_service_1.FirebaseService,
        auth_service_1.AuthService])
], UserService);
//# sourceMappingURL=user.service.js.map