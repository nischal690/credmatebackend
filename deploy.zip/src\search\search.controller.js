"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
const search_service_1 = require("./search.service");
const user_profile_response_dto_1 = require("../user/dto/user-profile-response.dto");
let SearchController = class SearchController {
    constructor(searchService) {
        this.searchService = searchService;
    }
    async searchByFace(file) {
        if (!file) {
            throw new common_1.BadRequestException('No image file uploaded');
        }
        return this.searchService.searchByFace(file.buffer);
    }
    async searchByMobileNumber(phoneNumber) {
        const user = await this.searchService.searchByMobileNumber(phoneNumber);
        if (!user) {
            throw new common_1.NotFoundException('User not found');
        }
        return user;
    }
    async searchById(userId) {
        const user = await this.searchService.searchById(userId);
        if (!user) {
            throw new common_1.NotFoundException('User not found');
        }
        return user;
    }
    async searchByAadhar(aadharNumber) {
        const user = await this.searchService.searchByAadhar(aadharNumber);
        if (!user) {
            throw new common_1.NotFoundException('User not found');
        }
        return user;
    }
    async searchByPanNumber(panNumber) {
        const user = await this.searchService.searchByPanNumber(panNumber);
        if (!user) {
            throw new common_1.NotFoundException('User not found');
        }
        return user;
    }
};
exports.SearchController = SearchController;
__decorate([
    (0, common_1.Post)('face'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('JWT-auth'),
    (0, swagger_1.ApiOperation)({
        summary: 'Search by face',
        description: 'Search for a user by comparing face with stored profile images',
    }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('image')),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SearchController.prototype, "searchByFace", null);
__decorate([
    (0, common_1.Get)('mobile/:phonenumber'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('JWT-auth'),
    (0, swagger_1.ApiOperation)({ summary: 'Search user by mobile number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'User found', type: user_profile_response_dto_1.UserProfileResponseDto }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'User not found' }),
    __param(0, (0, common_1.Param)('phonenumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SearchController.prototype, "searchByMobileNumber", null);
__decorate([
    (0, common_1.Get)('id/:userId'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('JWT-auth'),
    (0, swagger_1.ApiOperation)({ summary: 'Search user by ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'User found', type: user_profile_response_dto_1.UserProfileResponseDto }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'User not found' }),
    __param(0, (0, common_1.Param)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SearchController.prototype, "searchById", null);
__decorate([
    (0, common_1.Get)('aadhar/:aadharNumber'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('JWT-auth'),
    (0, swagger_1.ApiOperation)({ summary: 'Search user by Aadhar number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'User found', type: user_profile_response_dto_1.UserProfileResponseDto }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'User not found' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Invalid Aadhar number format' }),
    __param(0, (0, common_1.Param)('aadharNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SearchController.prototype, "searchByAadhar", null);
__decorate([
    (0, common_1.Get)('pan/:pannumber'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('JWT-auth'),
    (0, swagger_1.ApiOperation)({ summary: 'Search user by PAN number' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'User found', type: user_profile_response_dto_1.UserProfileResponseDto }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'User not found' }),
    __param(0, (0, common_1.Param)('pannumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SearchController.prototype, "searchByPanNumber", null);
exports.SearchController = SearchController = __decorate([
    (0, swagger_1.ApiTags)('Search'),
    (0, common_1.Controller)('search'),
    __metadata("design:paramtypes", [search_service_1.SearchService])
], SearchController);
//# sourceMappingURL=search.controller.js.map