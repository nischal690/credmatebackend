"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchService = void 0;
const common_1 = require("@nestjs/common");
const face_recognition_service_1 = require("./services/face-recognition.service");
const prisma_service_1 = require("../../database/prisma/prisma.service");
let SearchService = class SearchService {
    constructor(faceRecognitionService, prisma) {
        this.faceRecognitionService = faceRecognitionService;
        this.prisma = prisma;
    }
    async searchByFace(imageBuffer) {
        return this.faceRecognitionService.searchFaceByImage(imageBuffer);
    }
    async searchByMobileNumber(phoneNumber) {
        if (!phoneNumber) {
            throw new common_1.BadRequestException('Phone number is required');
        }
        const user = await this.prisma.user.findUnique({
            where: { phoneNumber },
            select: {
                name: true,
                date_of_birth: true,
                businessType: true,
            },
        });
        if (!user) {
            return null;
        }
        return user;
    }
    async searchById(userId) {
        if (!userId) {
            throw new common_1.BadRequestException('User ID is required');
        }
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            select: {
                name: true,
                date_of_birth: true,
                businessType: true,
            },
        });
        if (!user) {
            return null;
        }
        return user;
    }
    async searchByAadhar(aadhaarNumber) {
        console.log('Input Aadhaar number type:', typeof aadhaarNumber);
        console.log('Input Aadhaar number:', aadhaarNumber);
        if (!aadhaarNumber) {
            throw new common_1.BadRequestException('Aadhaar number is required');
        }
        const formattedAadhaar = aadhaarNumber.toString().padStart(12, '0');
        console.log('Formatted Aadhaar:', formattedAadhaar);
        if (!/^\d{12}$/.test(formattedAadhaar)) {
            throw new common_1.BadRequestException('Invalid Aadhaar number format. Must be 12 digits');
        }
        const allUsers = await this.prisma.user.findMany({
            take: 5,
        });
        console.log('First 5 users in database:', allUsers);
        const rawUsers = await this.prisma.$queryRaw `
      SELECT * FROM users WHERE "aadhaarNumber" = ${formattedAadhaar};
    `;
        console.log('Raw query result:', rawUsers);
        const user = await this.prisma.user.findFirst({
            where: {
                aadhaarNumber: formattedAadhaar,
            },
            select: {
                name: true,
                date_of_birth: true,
                businessType: true,
            },
        });
        console.log('Prisma query result:', user);
        if (!user) {
            return null;
        }
        return user;
    }
    async searchByPanNumber(panNumber) {
        if (!panNumber) {
            throw new common_1.BadRequestException('PAN number is required');
        }
        const user = await this.prisma.user.findUnique({
            where: { panNumber },
            select: {
                name: true,
                date_of_birth: true,
                businessType: true,
            },
        });
        if (!user) {
            return null;
        }
        return user;
    }
};
exports.SearchService = SearchService;
exports.SearchService = SearchService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [face_recognition_service_1.FaceRecognitionService,
        prisma_service_1.PrismaService])
], SearchService);
//# sourceMappingURL=search.service.js.map