"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthGuardFactory = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("../../auth/auth.service");
const firebase_service_1 = require("../../auth/firebase.service");
let AuthGuardFactory = class AuthGuardFactory {
    constructor(authService, firebaseService) {
        this.authService = authService;
        this.firebaseService = firebaseService;
    }
    createAuthGuard(type) {
        return {
            canActivate: async (context) => {
                const request = context.switchToHttp().getRequest();
                const token = this.extractToken(request);
                if (!token) {
                    throw new common_1.UnauthorizedException('No token provided');
                }
                try {
                    if (type === 'jwt') {
                        request.user = await this.authService.verifyCustomToken(token);
                    }
                    else {
                        request.user = await this.firebaseService.verifyIdToken(token);
                    }
                    return true;
                }
                catch (error) {
                    throw new common_1.UnauthorizedException('Invalid token');
                }
            },
        };
    }
    extractToken(request) {
        const authHeader = request.headers.authorization;
        if (!authHeader)
            return null;
        const [type, token] = authHeader.split(' ');
        return type === 'Bearer' ? token : null;
    }
};
exports.AuthGuardFactory = AuthGuardFactory;
exports.AuthGuardFactory = AuthGuardFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [auth_service_1.AuthService,
        firebase_service_1.FirebaseService])
], AuthGuardFactory);
//# sourceMappingURL=auth.guard.factory.js.map