"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FirebaseAuthError = void 0;
class FirebaseAuthError extends Error {
    constructor(code, message, details) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = 'FirebaseAuthError';
        Object.setPrototypeOf(this, FirebaseAuthError.prototype);
    }
}
exports.FirebaseAuthError = FirebaseAuthError;
//# sourceMappingURL=firebase-auth.error.js.map