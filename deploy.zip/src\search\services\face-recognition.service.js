"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FaceRecognitionService = void 0;
const common_1 = require("@nestjs/common");
const client_rekognition_1 = require("@aws-sdk/client-rekognition");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const aws_config_service_1 = require("../../common/config/aws.config.service");
const image_utils_1 = require("../../common/utils/image.utils");
let FaceRecognitionService = class FaceRecognitionService {
    constructor(awsConfigService) {
        this.awsConfigService = awsConfigService;
        const awsConfig = this.awsConfigService.getAwsConfig();
        const rekognitionConfig = this.awsConfigService.getRekognitionConfig();
        const dynamoDBConfig = this.awsConfigService.getDynamoDBConfig();
        this.rekognitionClient = new client_rekognition_1.RekognitionClient(awsConfig);
        this.dynamoDBClient = new client_dynamodb_1.DynamoDBClient(awsConfig);
        this.collectionId = rekognitionConfig.collectionId;
        this.faceMatchThreshold = rekognitionConfig.faceMatchThreshold;
        this.tableName = dynamoDBConfig.faceRecognitionTableName;
        this.initializeCollection();
    }
    async initializeCollection() {
        try {
            const command = new client_rekognition_1.CreateCollectionCommand({
                CollectionId: this.collectionId,
            });
            await this.rekognitionClient.send(command);
            console.log(`Collection ${this.collectionId} created successfully`);
        }
        catch (error) {
            if (error.name !== 'ResourceAlreadyExistsException') {
                console.error('Error creating collection:', error);
                throw error;
            }
        }
    }
    async searchFaceByImage(imageBuffer) {
        try {
            await image_utils_1.ImageUtils.validateImage(imageBuffer);
            const processedImageBuffer = await image_utils_1.ImageUtils.convertToJpeg(imageBuffer);
            const searchFacesCommand = new client_rekognition_1.SearchFacesByImageCommand({
                CollectionId: this.collectionId,
                Image: { Bytes: processedImageBuffer },
                FaceMatchThreshold: this.faceMatchThreshold,
                MaxFaces: 4
            });
            const response = await this.rekognitionClient.send(searchFacesCommand);
            if (!response.FaceMatches || response.FaceMatches.length === 0) {
                return [{ matched: false }];
            }
            return await Promise.all(response.FaceMatches.slice(0, 4).map(async (match) => {
                const rekognitionId = match.Face?.FaceId;
                let fullName = null;
                if (rekognitionId) {
                    const getItemCommand = new client_dynamodb_1.GetItemCommand({
                        TableName: this.tableName,
                        Key: {
                            RekognitionId: { S: rekognitionId }
                        }
                    });
                    const dynamoResponse = await this.dynamoDBClient.send(getItemCommand);
                    if (dynamoResponse.Item) {
                        fullName = dynamoResponse.Item.FullName?.S;
                    }
                }
                return {
                    matched: true,
                    Similarity: match.Similarity,
                    FullName: fullName
                };
            }));
        }
        catch (error) {
            console.error('Error in face search:', error);
            throw error;
        }
    }
    async getUserDetails(rekognitionId) {
        try {
            const getItemCommand = new client_dynamodb_1.GetItemCommand({
                TableName: this.tableName,
                Key: {
                    RekognitionId: { S: rekognitionId }
                }
            });
            const response = await this.dynamoDBClient.send(getItemCommand);
            if (!response.Item) {
                return {};
            }
            return {
                matchedUserId: response.Item.userId?.S,
                fullName: response.Item.FullName?.S,
                metadata: response.Item.metadata?.S
            };
        }
        catch (error) {
            console.error('Error fetching user details:', error);
            return {};
        }
    }
};
exports.FaceRecognitionService = FaceRecognitionService;
exports.FaceRecognitionService = FaceRecognitionService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [aws_config_service_1.AwsConfigService])
], FaceRecognitionService);
//# sourceMappingURL=face-recognition.service.js.map